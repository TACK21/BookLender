package com.TheBoys.Booklender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooklenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
