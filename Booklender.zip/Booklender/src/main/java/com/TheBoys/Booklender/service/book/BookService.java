package com.TheBoys.Booklender.service.book;

import com.TheBoys.Booklender.dto.BookDto;
import com.TheBoys.Booklender.dto.UserDto;
import com.TheBoys.Booklender.model.Book;
import com.TheBoys.Booklender.model.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public interface BookService {


    List<BookDto> getAllBooks();

    List<UserDto> getOwners(long bookId);
}
