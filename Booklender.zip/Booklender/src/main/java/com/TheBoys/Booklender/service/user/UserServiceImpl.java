package com.TheBoys.Booklender.service.user;

import com.TheBoys.Booklender.model.Book;
import com.TheBoys.Booklender.model.User;
import com.TheBoys.Booklender.repository.BookRepository;
import com.TheBoys.Booklender.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.List;
import java.util.Optional;
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserServiceImpl implements UserService{
    private final BookRepository bookRepository;
    private final UserRepository userRepository;


    @Override
    public void takeBook(long userId, long bookId) {
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Book> bookOptional = bookRepository.findById(bookId);

        if (userOptional.isPresent() && bookOptional.isPresent()) {
            User user = userOptional.get();
            Book book = bookOptional.get();
            if (book.getQuantity() == 0) {
                throw new BookNotFoundException("БОЛЬШЕ КНИГ ЭТОГО АВТОРА НЕ ОСТАЛОСЬ");
            }

            if (user.getBooks().size() != 2){
                book.getOwners().add(user);
                user.getBooks().add(book);
            }else {
                throw new BookNotFoundException("Больше книг нельзя!!!");
            }
            book.setOwners(userRepository.getOwnersByBookId(bookId));
            user.setBooks(bookRepository.getBooksByOwnerId(userId));
            book.setQuantity(book.getQuantity() - 1);
            if (book.getQuantity() == 0) {
                book.setStatus("ЗАКОНЧИЛОСЬ");
            }
            userRepository.save(user);
            bookRepository.save(book);
        }
    }


    @ExceptionHandler(BookNotFoundException.class)
    public ResponseEntity<String> handleBookNotFoundException(BookNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }
    public static class BookNotFoundException extends RuntimeException {
        public BookNotFoundException(String message) {
            super(message);
        }
    }

    @Override
    public void returnBook(long userId,long bookId){
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Book> bookOptional = bookRepository.findById(bookId);

        if (userOptional.isPresent() && bookOptional.isPresent()) {
            User user = userOptional.get();
            Book book = bookOptional.get();

            List<User> owners = userRepository.getOwnersByBookId(bookId);
            List<Book> books = bookRepository.getBooksByOwnerId(userId);

            owners.remove(user);
            books.remove(book);

            book.setOwners(owners);
            user.setBooks(books);


            book.setQuantity(book.getQuantity()+1);
            if(book.getQuantity() >= 1){
                book.setStatus("Есть на складе");
            }
            userRepository.save(user);
            bookRepository.save(book);

        }
    }







}
