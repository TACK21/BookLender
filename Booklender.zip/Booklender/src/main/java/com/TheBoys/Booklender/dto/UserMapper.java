package com.TheBoys.Booklender.dto;

import com.TheBoys.Booklender.model.User;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class UserMapper {
    private final ModelMapper modelMapper;

    public UserDto getUserDto(User user){
        return modelMapper.map(user, UserDto.class);
    }
    public List<UserDto> getUserDtoList(List<User> users){
        List<UserDto> userDtoList = new ArrayList<>();
        for (User user : users){
            userDtoList.add(getUserDto(user));
        }
        return userDtoList;
    }
}
