package com.TheBoys.Booklender.repository;

import com.TheBoys.Booklender.model.Book;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book,Long> {

    @Query("""
        SELECT b
        FROM Book b
        LEFT JOIN FETCH b.owners
""")
    List<Book> getBooksWithOwners();

    @Query("""
                SELECT b
                FROM Book b
                LEFT JOIN FETCH b.owners o
                WHERE o.id = :userId
            """)
    List<Book> getBooksByOwnerId(long userId);
}
