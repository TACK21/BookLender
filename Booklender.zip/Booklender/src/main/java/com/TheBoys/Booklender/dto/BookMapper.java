package com.TheBoys.Booklender.dto;

import com.TheBoys.Booklender.model.Book;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class BookMapper {
    private final ModelMapper modelMapper;

    public BookDto getBookDto(Book book){
        return modelMapper.map(book, BookDto.class);
    }
    public List<BookDto> getBookDtoList(List<Book> books){
        List<BookDto> bookDtoList = new ArrayList<>();
        for (Book book : books){
            bookDtoList.add(getBookDto(book));
        }
        return bookDtoList;
    }
}
