package com.TheBoys.Booklender.service.book;


import com.TheBoys.Booklender.dto.BookDto;
import com.TheBoys.Booklender.dto.BookMapper;
import com.TheBoys.Booklender.dto.UserDto;
import com.TheBoys.Booklender.dto.UserMapper;
import com.TheBoys.Booklender.model.Book;
import com.TheBoys.Booklender.model.User;
import com.TheBoys.Booklender.repository.BookRepository;
import com.TheBoys.Booklender.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class BookServiceImpl implements BookService{
    private final BookRepository bookRepository;
    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final BookMapper bookMapper;

    @Override
    public List<BookDto> getAllBooks(){
        List<Book> books = bookRepository.getBooksWithOwners();
        return bookMapper.getBookDtoList(books);
    }

    @Override
    public List<UserDto> getOwners(long bookId){
        List<User> owners = userRepository.getOwnersByBookId(bookId);
        Book book = bookRepository.findById(bookId).orElse(null);
        for (User user : owners) {
            Hibernate.initialize(user.getBooks());
            Hibernate.initialize(book.getOwners());
        }
        return userMapper.getUserDtoList(owners);

    }
}
