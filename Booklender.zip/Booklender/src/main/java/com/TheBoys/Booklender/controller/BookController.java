package com.TheBoys.Booklender.controller;

import com.TheBoys.Booklender.dto.BookDto;
import com.TheBoys.Booklender.dto.UserDto;
import com.TheBoys.Booklender.model.Book;
import com.TheBoys.Booklender.model.User;
import com.TheBoys.Booklender.service.book.BookService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class BookController {
    private final BookService bookService;

    @GetMapping("/get")
    @Operation(summary = "get info about all books")
    public List<BookDto> getAllBooksInfo() {
        return bookService.getAllBooks();
    }

    @GetMapping("/getInfo")
    @Operation(summary = "get info about book")
    public List<UserDto> getBookOwners(long bookId) {
        return bookService.getOwners(bookId);
    }
}
