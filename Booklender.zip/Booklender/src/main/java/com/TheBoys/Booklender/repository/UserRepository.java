package com.TheBoys.Booklender.repository;

import com.TheBoys.Booklender.model.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    Optional<User> getByUsername(String username);

    @Query("""
    SELECT DISTINCT u
    FROM User u
    JOIN FETCH u.books b
    WHERE b.id = :bookId
""")
    List<User> getOwnersByBookId(long bookId);
}
