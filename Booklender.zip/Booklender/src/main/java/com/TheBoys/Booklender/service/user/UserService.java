package com.TheBoys.Booklender.service.user;

import org.springframework.stereotype.Service;

@Service
public interface UserService {
    void takeBook(long userId, long bookId);

    void returnBook(long userId, long bookId);
}
