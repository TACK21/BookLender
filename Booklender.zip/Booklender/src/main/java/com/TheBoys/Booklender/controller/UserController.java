package com.TheBoys.Booklender.controller;

import com.TheBoys.Booklender.service.user.UserService;
import com.TheBoys.Booklender.service.user.UserServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class UserController {

    private final UserService userService;

    @PostMapping("/takeBook/{userId}/{bookId}")
    public ResponseEntity<String> takeBook(@PathVariable long userId, @PathVariable long bookId) {
        try {
            userService.takeBook(userId, bookId);
            return ResponseEntity.ok("Книга успешно выбрана");
        } catch (UserServiceImpl.BookNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }
    @PostMapping("/returnBook/{userId}/{bookId}")
    @Operation(summary = "User return a book")
    public void returnBook(@PathVariable long userId,@PathVariable long bookId) {
        userService.returnBook(userId,bookId);
    }



}
