package com.TheBoys.Booklender.controller;

import com.TheBoys.Booklender.dto.AuthRequest;
import com.TheBoys.Booklender.dto.AuthResponse;
import com.TheBoys.Booklender.service.security.IdentityService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class IdentityController {

    private final IdentityService identityService;

    @PostMapping("/register")
    @Operation(summary = "User registration", description = "Login user  (Get JWT token)")
    public ResponseEntity<AuthResponse> register(@RequestBody AuthRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(identityService.registerUser(request));
    }

    @PostMapping("/login")
    @Operation(summary = "User authentication", description = "Login user  (Get JWT token)")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest authRequest) {
        return ResponseEntity.ok(identityService.login(authRequest));
    }



}
